class Note {
  final String id;

  final String title;
  final String text;

  final int color;

  final DateTime createdAt;
  final DateTime updatedAt;

  final bool pinned;
  final String? imagePath;

  // 🎨 Atmosphere
  final String atmosphere;

  // 😊 Mood
  final String? mood;

  // 🌙 Night Notes
  final bool isNightNote;

  // 🔗 Note Connections
  final List<String> connectedNoteIds;

  // ✨ Capture Thought
  final bool isQuickThought;

  const Note({
    required this.id,
    required this.title,
    required this.text,
    required this.color,
    required this.createdAt,
    required this.updatedAt,
    this.pinned = false,
    this.imagePath,
    this.atmosphere = 'soft',
    this.mood,
    this.isNightNote = false,
    this.connectedNoteIds = const [],
    this.isQuickThought = false,
  });

  Note copyWith({
    String? id,
    String? title,
    String? text,
    int? color,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? pinned,
    String? imagePath,
    String? atmosphere,
    String? mood,
    bool? isNightNote,
    List<String>? connectedNoteIds,
    bool? isQuickThought,
  }) {
    return Note(
      id: id ?? this.id,
      title: title ?? this.title,
      text: text ?? this.text,
      color: color ?? this.color,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      pinned: pinned ?? this.pinned,
      imagePath: imagePath ?? this.imagePath,
      atmosphere: atmosphere ?? this.atmosphere,
      mood: mood ?? this.mood,
      isNightNote: isNightNote ?? this.isNightNote,
      connectedNoteIds:
          connectedNoteIds ?? this.connectedNoteIds,
      isQuickThought:
          isQuickThought ?? this.isQuickThought,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'text': text,
      'color': color,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'pinned': pinned,
      'imagePath': imagePath,
      'atmosphere': atmosphere,
      'mood': mood,
      'isNightNote': isNightNote,
      'connectedNoteIds': connectedNoteIds,
      'isQuickThought': isQuickThought,
    };
  }

  factory Note.fromMap(Map<String, dynamic> map) {
    final createdAt =
        DateTime.tryParse(
              map['createdAt']?.toString() ?? '',
            ) ??
            DateTime.now();

    final updatedAt =
        DateTime.tryParse(
              map['updatedAt']?.toString() ?? '',
            ) ??
            createdAt;

    return Note(
      id: map['id']?.toString() ??
          createdAt.microsecondsSinceEpoch.toString(),

      title: map['title']?.toString() ?? '',

      text: map['text']?.toString() ?? '',

      color: map['color'] is int
          ? map['color']
          : 0xFFFFDDE6,

      createdAt: createdAt,

      updatedAt: updatedAt,

      pinned: map['pinned'] == true,

      imagePath: map['imagePath']?.toString(),

      atmosphere:
          map['atmosphere']?.toString() ?? 'soft',

      mood: map['mood']?.toString(),

      isNightNote:
          map['isNightNote'] == true,

      connectedNoteIds:
          map['connectedNoteIds'] is List
              ? List<String>.from(
                  map['connectedNoteIds']
                      .map((item) => item.toString()),
                )
              : const [],

      isQuickThought:
          map['isQuickThought'] == true,
    );
  }
}