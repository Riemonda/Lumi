import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/note.dart';

class Store {
  static const String key = 'notes';

  /// 💾 Save all notes locally
  static Future<void> save(List<Note> notes) async {
    final prefs = await SharedPreferences.getInstance();

    final data = notes.map((note) {
      return note.toMap();
    }).toList();

    await prefs.setString(
      key,
      jsonEncode(data),
    );
  }

  /// 📂 Load all notes
  static Future<List<Note>> load() async {
    final prefs = await SharedPreferences.getInstance();

    final data = prefs.getString(key);

    if (data == null || data.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(data);

      if (decoded is! List) {
        return [];
      }

      final List<Note> notes = [];

      for (final item in decoded) {
        if (item is! Map) {
          continue;
        }

        try {
          final map = Map<String, dynamic>.from(item);

          final note = Note.fromMap(map);

          notes.add(note);
        } catch (_) {
          // تجاهل الملاحظة التالفة بدلًا من إيقاف تحميل كل الملاحظات
          continue;
        }
      }

      return notes;
    } catch (_) {
      return [];
    }
  }

  /// 🗑️ Delete all saved notes
  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.remove(key);
  }

  /// 🔄 Check whether notes exist
  static Future<bool> hasNotes() async {
    final prefs = await SharedPreferences.getInstance();

    final data = prefs.getString(key);

    return data != null && data.isNotEmpty;
  }

  /// 📊 Number of saved notes
  static Future<int> count() async {
    final notes = await load();

    return notes.length;
  }
}