import 'dart:io';

import 'package:flutter/material.dart';

class NoteCard extends StatelessWidget {
  final String title;
  final String text;
  final Color color;
  final String? imagePath;
  final bool pinned;

  final DateTime createdAt;
  final DateTime updatedAt;

  final String atmosphere;
  final String? mood;
  final bool isNightNote;
  final bool isQuickThought;

  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final VoidCallback? onPin;

  const NoteCard({
    super.key,
    required this.title,
    required this.text,
    required this.color,
    this.imagePath,
    this.pinned = false,
    required this.createdAt,
    required this.updatedAt,
    this.atmosphere = 'soft',
    this.mood,
    this.isNightNote = false,
    this.isQuickThought = false,
    this.onTap,
    this.onDelete,
    this.onPin,
  });

  Future<void> _confirmDelete(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Delete note?'),
          content: const Text(
            'Are you sure you want to delete this note?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (result == true) {
      onDelete?.call();
    }
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final year = date.year.toString();

    final hour = date.hour == 0
        ? 12
        : date.hour > 12
            ? date.hour - 12
            : date.hour;

    final minute = date.minute.toString().padLeft(2, '0');

    final period = date.hour >= 12 ? 'PM' : 'AM';

    return '$day/$month/$year · $hour:$minute $period';
  }

  bool get wasUpdated {
    return updatedAt.difference(createdAt).inSeconds > 1;
  }

  String _atmosphereName() {
    switch (atmosphere) {
      case 'midnight':
        return 'Midnight';
      case 'calm':
        return 'Calm';
      case 'nature':
        return 'Nature';
      case 'dreamy':
        return 'Dreamy';
      case 'cozy':
        return 'Cozy';
      default:
        return 'Soft';
    }
  }

  IconData _atmosphereIcon() {
    switch (atmosphere) {
      case 'midnight':
        return Icons.nightlight_outlined;
      case 'calm':
        return Icons.cloud_outlined;
      case 'nature':
        return Icons.eco_outlined;
      case 'dreamy':
        return Icons.auto_awesome_outlined;
      case 'cozy':
        return Icons.local_cafe_outlined;
      default:
        return Icons.local_florist_outlined;
    }
  }

  String _moodName() {
    switch (mood) {
      case 'happy':
        return 'Happy';
      case 'calm':
        return 'Calm';
      case 'sad':
        return 'Sad';
      case 'love':
        return 'Love';
      case 'thoughtful':
        return 'Thoughtful';
      case 'excited':
        return 'Excited';
      default:
        return '';
    }
  }

  IconData _moodIcon() {
    switch (mood) {
      case 'happy':
        return Icons.sentiment_very_satisfied_outlined;
      case 'calm':
        return Icons.sentiment_satisfied_outlined;
      case 'sad':
        return Icons.sentiment_dissatisfied_outlined;
      case 'love':
        return Icons.favorite_border_rounded;
      case 'thoughtful':
        return Icons.psychology_outlined;
      case 'excited':
        return Icons.bolt_outlined;
      default:
        return Icons.mood_outlined;
    }
  }

  Widget _tag({
    required IconData icon,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.65),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: Colors.black87,
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: const TextStyle(
              color: Colors.black87,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark =
        Theme.of(context).brightness == Brightness.dark;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              isDark ? 0.15 : 0.06,
            ),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (imagePath != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.file(
                    File(imagePath!),
                    width: double.infinity,
                    height: 170,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 14),
              ],

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      title.isEmpty ? 'Untitled' : title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  if (pinned)
                    const Padding(
                      padding: EdgeInsets.only(
                        top: 2,
                        right: 4,
                      ),
                      child: Icon(
                        Icons.push_pin_rounded,
                        color: Colors.black87,
                        size: 19,
                      ),
                    ),

                  PopupMenuButton<String>(
                    padding: EdgeInsets.zero,
                    icon: const Icon(
                      Icons.more_horiz,
                      color: Colors.black87,
                    ),
                    onSelected: (value) {
                      if (value == 'pin') {
                        onPin?.call();
                      }

                      if (value == 'delete') {
                        _confirmDelete(context);
                      }
                    },
                    itemBuilder: (context) {
                      return [
                        PopupMenuItem(
                          value: 'pin',
                          child: Row(
                            children: [
                              Icon(
                                pinned
                                    ? Icons.push_pin_outlined
                                    : Icons.push_pin,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                pinned ? 'Unpin' : 'Pin',
                              ),
                            ],
                          ),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Row(
                            children: [
                              Icon(Icons.delete_outline),
                              SizedBox(width: 10),
                              Text('Delete'),
                            ],
                          ),
                        ),
                      ];
                    },
                  ),
                ],
              ),

              if (isQuickThought) ...[
                const SizedBox(height: 10),
                _tag(
                  icon: Icons.bolt_rounded,
                  label: 'Quick Thought',
                ),
              ],

              if (text.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  text,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 14,
                    height: 1.5,
                  ),
                ),
              ],

              const SizedBox(height: 12),

              Wrap(
                spacing: 7,
                runSpacing: 7,
                children: [
                  _tag(
                    icon: _atmosphereIcon(),
                    label: _atmosphereName(),
                  ),

                  if (mood != null)
                    _tag(
                      icon: _moodIcon(),
                      label: _moodName(),
                    ),

                  if (isNightNote)
                    _tag(
                      icon: Icons.nightlight_round,
                      label: 'Night Note',
                    ),
                ],
              ),

              const SizedBox(height: 14),

              Row(
                children: [
                  const Icon(
                    Icons.schedule_rounded,
                    size: 14,
                    color: Colors.black54,
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      'Created · ${_formatDate(createdAt)}',
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),

              if (wasUpdated) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(
                      Icons.edit_outlined,
                      size: 14,
                      color: Colors.black54,
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        'Updated · ${_formatDate(updatedAt)}',
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}