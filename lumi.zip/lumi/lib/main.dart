import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/home_screen.dart';
import 'theme/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final prefs = await SharedPreferences.getInstance();

  final savedTheme = prefs.getString('theme') ?? 'system';

  ThemeMode themeMode;

  if (savedTheme == 'light') {
    themeMode = ThemeMode.light;
  } else if (savedTheme == 'dark') {
    themeMode = ThemeMode.dark;
  } else {
    themeMode = ThemeMode.system;
  }

  runApp(
    Lumi(
      initialTheme: themeMode,
    ),
  );
}

class Lumi extends StatefulWidget {
  final ThemeMode initialTheme;

  const Lumi({
    super.key,
    required this.initialTheme,
  });

  @override
  State<Lumi> createState() => _LumiState();
}

class _LumiState extends State<Lumi> {
  late ThemeMode themeMode;

  @override
  void initState() {
    super.initState();
    themeMode = widget.initialTheme;
  }

  Future<void> changeTheme(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();

    String value;

    if (mode == ThemeMode.light) {
      value = 'light';
    } else if (mode == ThemeMode.dark) {
      value = 'dark';
    } else {
      value = 'system';
    }

    await prefs.setString('theme', value);

    setState(() {
      themeMode = mode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Lumi',

      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,

      home: HomeScreen(
        onThemeChanged: changeTheme,
        themeMode: themeMode,
      ),
    );
  }
}