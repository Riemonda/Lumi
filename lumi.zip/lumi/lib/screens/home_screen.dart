import 'package:flutter/material.dart';

import '../data/store.dart';
import '../models/note.dart';
import '../widgets/note_card.dart';
import 'add.dart';
import 'edit.dart';

class HomeScreen extends StatefulWidget {
  final void Function(ThemeMode) onThemeChanged;
  final ThemeMode themeMode;

  const HomeScreen({
    super.key,
    required this.onThemeChanged,
    required this.themeMode,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Note> notes = [];
  String search = '';

  @override
  void initState() {
    super.initState();
    loadNotes();
  }

  Future<void> loadNotes() async {
    final savedNotes = await Store.load();

    if (!mounted) return;

    setState(() {
      notes = savedNotes;
    });
  }

  Future<void> addNote() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const AddScreen(),
      ),
    );

    if (result == null) return;

    final now = DateTime.now();

    final isNightNote =
        now.hour >= 21 || now.hour < 6;

    final note = Note(
      id: DateTime.now()
          .microsecondsSinceEpoch
          .toString(),
      title: result['title'] ?? '',
      text: result['text'] ?? '',
      color: result['color'] ?? 0xFFFFDDE6,
      createdAt: now,
      updatedAt: now,
      pinned: result['pinned'] ?? false,
      imagePath: result['imagePath'],
      atmosphere:
          result['atmosphere'] ?? 'soft',
      mood: result['mood'],
      isNightNote:
          result['isNightNote'] ??
          isNightNote,
      connectedNoteIds:
          List<String>.from(
        result['connectedNoteIds'] ?? [],
      ),
      isQuickThought:
          result['isQuickThought'] ?? false,
    );

    setState(() {
      notes.add(note);
    });

    await Store.save(notes);
  }

  Future<void> editNote(Note note) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditScreen(
          note: note,
        ),
      ),
    );

    if (result == null) return;

    final index = notes.indexOf(note);

    if (index == -1) return;

    final oldConnections =
        Set<String>.from(
      note.connectedNoteIds,
    );

    final updatedNote = result.copyWith(
      updatedAt: DateTime.now(),
    );

    setState(() {
      notes[index] = updatedNote;
    });

    await _syncConnections(
      updatedNote,
      oldConnections,
    );
  }

  Future<void> _syncConnections(
    Note updatedNote,
    Set<String> oldConnections,
  ) async {
    final newConnections =
        Set<String>.from(
      updatedNote.connectedNoteIds,
    );

    final allNoteIds =
        <String>{
      ...oldConnections,
      ...newConnections,
    };

    for (final otherNoteId in allNoteIds) {
      if (otherNoteId == updatedNote.id) {
        continue;
      }

      final otherIndex = notes.indexWhere(
        (note) => note.id == otherNoteId,
      );

      if (otherIndex == -1) {
        continue;
      }

      final otherNote = notes[otherIndex];

      final otherConnections =
          Set<String>.from(
        otherNote.connectedNoteIds,
      );

      final shouldBeConnected =
          newConnections.contains(
        otherNote.id,
      );

      if (shouldBeConnected) {
        otherConnections.add(
          updatedNote.id,
        );
      } else {
        otherConnections.remove(
          updatedNote.id,
        );
      }

      final updatedOtherNote =
          otherNote.copyWith(
        connectedNoteIds:
            otherConnections.toList(),
        updatedAt: DateTime.now(),
      );

      setState(() {
        notes[otherIndex] =
            updatedOtherNote;
      });
    }

    await Store.save(notes);
  }

  Future<void> deleteNote(Note note) async {
    setState(() {
      notes.remove(note);
    });

    for (var i = 0; i < notes.length; i++) {
      final currentNote = notes[i];

      if (currentNote.connectedNoteIds
          .contains(note.id)) {
        final updatedIds =
            List<String>.from(
          currentNote.connectedNoteIds,
        )..remove(note.id);

        notes[i] = currentNote.copyWith(
          connectedNoteIds: updatedIds,
          updatedAt: DateTime.now(),
        );
      }
    }

    await Store.save(notes);
  }

  Future<void> togglePin(Note note) async {
    final index = notes.indexOf(note);

    if (index == -1) return;

    final updatedNote = note.copyWith(
      pinned: !note.pinned,
      updatedAt: DateTime.now(),
    );

    setState(() {
      notes[index] = updatedNote;
    });

    await Store.save(notes);
  }

  List<Note> get filteredNotes {
    List<Note> result = List.from(notes);

    final query =
        search.trim().toLowerCase();

    if (query.isNotEmpty) {
      result = result.where((note) {
        final title =
            note.title.toLowerCase();

        final text =
            note.text.toLowerCase();

        final atmosphere =
            note.atmosphere.toLowerCase();

        final mood =
            note.mood?.toLowerCase() ?? '';

        final nightNote =
            note.isNightNote
                ? 'night note night'
                : '';

        final quickThought =
            note.isQuickThought
                ? 'quick thought'
                : '';

        return title.contains(query) ||
            text.contains(query) ||
            atmosphere.contains(query) ||
            mood.contains(query) ||
            nightNote.contains(query) ||
            quickThought.contains(query);
      }).toList();
    }

    result.sort((a, b) {
      if (a.pinned && !b.pinned) {
        return -1;
      }

      if (!a.pinned && b.pinned) {
        return 1;
      }

      return b.updatedAt.compareTo(
        a.updatedAt,
      );
    });

    return result;
  }

  void showThemeMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor:
          Theme.of(context)
              .scaffoldBackgroundColor,
      shape:
          const RoundedRectangleBorder(
        borderRadius:
            BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding:
                const EdgeInsets.fromLTRB(
              20,
              12,
              20,
              20,
            ),
            child: Column(
              mainAxisSize:
                  MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 5,
                  decoration:
                      BoxDecoration(
                    color:
                        Colors.grey.shade400,
                    borderRadius:
                        BorderRadius.circular(
                      10,
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                const Align(
                  alignment:
                      Alignment.centerLeft,
                  child: Text(
                    'Appearance',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                themeOption(
                  icon:
                      Icons.light_mode_outlined,
                  title: 'Light',
                  mode: ThemeMode.light,
                ),
                themeOption(
                  icon:
                      Icons.dark_mode_outlined,
                  title: 'Dark',
                  mode: ThemeMode.dark,
                ),
                themeOption(
                  icon:
                      Icons.phone_android_outlined,
                  title: 'System',
                  mode: ThemeMode.system,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget themeOption({
    required IconData icon,
    required String title,
    required ThemeMode mode,
  }) {
    final selected =
        widget.themeMode == mode;

    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(
        horizontal: 8,
      ),
      leading: Icon(icon),
      title: Text(title),
      trailing: selected
          ? const Icon(
              Icons.check_rounded,
            )
          : null,
      onTap: () {
        widget.onThemeChanged(mode);
        Navigator.pop(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final visibleNotes =
        filteredNotes;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 20,
        title: const Text(
          'Lumi',
          style: TextStyle(
            fontSize: 30,
            fontWeight:
                FontWeight.w800,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Appearance',
            onPressed: showThemeMenu,
            icon: const Icon(
              Icons.palette_outlined,
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Padding(
        padding:
            const EdgeInsets.fromLTRB(
          20,
          8,
          20,
          20,
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Text(
              'Your little space for thoughts ✨',
              style: TextStyle(
                fontSize: 16,
                color: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.color
                    ?.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 22),
            TextField(
              onChanged: (value) {
                setState(() {
                  search = value;
                });
              },
              decoration:
                  const InputDecoration(
                hintText:
                    'Search your notes...',
                prefixIcon: Icon(
                  Icons.search_rounded,
                ),
              ),
            ),
            const SizedBox(height: 26),
            Row(
              mainAxisAlignment:
                  MainAxisAlignment
                      .spaceBetween,
              children: [
                const Text(
                  'My Notes',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
                if (notes.isNotEmpty)
                  Text(
                    '${visibleNotes.length}',
                    style: TextStyle(
                      color: Theme.of(
                        context,
                      )
                          .colorScheme
                          .primary,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: visibleNotes.isEmpty
                  ? _emptyState()
                  : ListView.builder(
                      padding:
                          const EdgeInsets
                              .only(
                        bottom: 90,
                      ),
                      itemCount:
                          visibleNotes.length,
                      itemBuilder:
                          (context, index) {
                        final note =
                            visibleNotes[
                                index];

                        return NoteCard(
                          title: note.title,
                          text: note.text,
                          color:
                              Color(note.color),
                          imagePath:
                              note.imagePath,
                          pinned: note.pinned,
                          createdAt:
                              note.createdAt,
                          updatedAt:
                              note.updatedAt,
                          atmosphere:
                              note.atmosphere,
                          mood: note.mood,
                          isNightNote:
                              note.isNightNote,
                          isQuickThought:
                              note.isQuickThought,
                          onTap: () {
                            editNote(note);
                          },
                          onDelete: () {
                            deleteNote(note);
                          },
                          onPin: () {
                            togglePin(note);
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton:
          FloatingActionButton(
        onPressed: addNote,
        child: const Icon(
          Icons.add_rounded,
          size: 28,
        ),
      ),
    );
  }

  Widget _emptyState() {
    final hasSearch =
        search.trim().isNotEmpty;

    return Center(
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Container(
            width: 82,
            height: 82,
            decoration:
                BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primary
                  .withOpacity(0.10),
              shape: BoxShape.circle,
            ),
            child: Icon(
              hasSearch
                  ? Icons.search_off_rounded
                  : Icons.auto_awesome_rounded,
              size: 38,
              color: Theme.of(context)
                  .colorScheme
                  .primary,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            hasSearch
                ? 'No notes found'
                : 'No notes yet',
            style: const TextStyle(
              fontSize: 20,
              fontWeight:
                  FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            hasSearch
                ? 'Try searching for something else.'
                : 'Create your first little thought ✨',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.color
                  ?.withOpacity(0.55),
            ),
          ),
        ],
      ),
    );
  }
}