import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../data/store.dart';
import '../models/note.dart';

class AddScreen extends StatefulWidget {
  const AddScreen({
    super.key,
  });

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  final titleController = TextEditingController();
  final textController = TextEditingController();

  final picker = ImagePicker();

  Color selectedColor = const Color(0xFFFFDDE6);

  String? imagePath;

  bool pinned = false;
  bool isQuickThought = false;
  bool isNightNote = false;

  String selectedAtmosphere = 'soft';
  String? selectedMood;

  List<Note> availableNotes = [];
  final Set<String> connectedNoteIds = {};

  final colors = [
    const Color(0xFFFFDDE6),
    const Color(0xFFE6DDFF),
    const Color(0xFFDDF4FF),
    const Color(0xFFE0F5D8),
    const Color(0xFFFFF0C9),
    const Color(0xFFFFE1CC),
  ];

  final atmospheres = [
    {
      'id': 'soft',
      'name': 'Soft',
      'icon': Icons.local_florist_outlined,
    },
    {
      'id': 'midnight',
      'name': 'Midnight',
      'icon': Icons.nightlight_outlined,
    },
    {
      'id': 'calm',
      'name': 'Calm',
      'icon': Icons.cloud_outlined,
    },
    {
      'id': 'nature',
      'name': 'Nature',
      'icon': Icons.eco_outlined,
    },
    {
      'id': 'dreamy',
      'name': 'Dreamy',
      'icon': Icons.auto_awesome_outlined,
    },
    {
      'id': 'cozy',
      'name': 'Cozy',
      'icon': Icons.local_cafe_outlined,
    },
  ];

  final moods = [
    {
      'id': 'happy',
      'name': 'Happy',
      'icon': Icons.sentiment_very_satisfied_outlined,
    },
    {
      'id': 'calm',
      'name': 'Calm',
      'icon': Icons.sentiment_satisfied_outlined,
    },
    {
      'id': 'sad',
      'name': 'Sad',
      'icon': Icons.sentiment_dissatisfied_outlined,
    },
    {
      'id': 'love',
      'name': 'Love',
      'icon': Icons.favorite_border_rounded,
    },
    {
      'id': 'thoughtful',
      'name': 'Thoughtful',
      'icon': Icons.psychology_outlined,
    },
    {
      'id': 'excited',
      'name': 'Excited',
      'icon': Icons.bolt_outlined,
    },
  ];

  @override
  void initState() {
    super.initState();
    loadNotes();
  }

  Future<void> loadNotes() async {
    final notes = await Store.load();

    if (!mounted) return;

    setState(() {
      availableNotes = notes;
    });
  }

  @override
  void dispose() {
    titleController.dispose();
    textController.dispose();
    super.dispose();
  }

  Future<void> pickImage() async {
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
    );

    if (image == null) return;

    final dir = await getApplicationDocumentsDirectory();

    final fileName =
        '${DateTime.now().millisecondsSinceEpoch}.jpg';

    final savedImage = await File(image.path).copy(
      '${dir.path}/$fileName',
    );

    if (!mounted) return;

    setState(() {
      imagePath = savedImage.path;
    });
  }

  void removeImage() {
    setState(() {
      imagePath = null;
    });
  }

  void save() {
    final title = titleController.text.trim();
    final text = textController.text.trim();

    if (title.isEmpty &&
        text.isEmpty &&
        imagePath == null) {
      return;
    }

    Navigator.pop(
      context,
      {
        'title': title,
        'text': text,
        'color': selectedColor.value,
        'pinned': pinned,
        'imagePath': imagePath,
        'atmosphere': selectedAtmosphere,
        'mood': selectedMood,
        'isNightNote': isNightNote,
        'connectedNoteIds':
            connectedNoteIds.toList(),
        'isQuickThought': isQuickThought,
      },
    );
  }

  void showConnections() {
    if (availableNotes.isEmpty) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text(
              'No notes to connect',
            ),
            content: const Text(
              'Create another note first, then you can connect notes together.',
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );

      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor:
          Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  12,
                  20,
                  20,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 42,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade400,
                        borderRadius:
                            BorderRadius.circular(10),
                      ),
                    ),

                    const SizedBox(height: 18),

                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Connect Notes',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),
                    ),

                    const SizedBox(height: 6),

                    Align(
                      alignment:
                          Alignment.centerLeft,
                      child: Text(
                        'Choose notes related to this thought.',
                        style: TextStyle(
                          color: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.color
                              ?.withOpacity(0.6),
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Flexible(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount:
                            availableNotes.length,
                        itemBuilder:
                            (context, index) {
                          final note =
                              availableNotes[index];

                          final id = note.id;

                          final selected =
                              connectedNoteIds
                                  .contains(id);

                          return CheckboxListTile(
                            value: selected,
                            onChanged: (value) {
                              setSheetState(() {
                                if (value == true) {
                                  connectedNoteIds
                                      .add(id);
                                } else {
                                  connectedNoteIds
                                      .remove(id);
                                }
                              });

                              setState(() {});
                            },
                            title: Text(
                              note.title.isEmpty
                                  ? 'Untitled'
                                  : note.title,
                              maxLines: 1,
                              overflow:
                                  TextOverflow.ellipsis,
                            ),
                            subtitle:
                                note.text.isEmpty
                                    ? null
                                    : Text(
                                        note.text,
                                        maxLines: 1,
                                        overflow:
                                            TextOverflow
                                                .ellipsis,
                                      ),
                            secondary: Icon(
                              Icons.link_rounded,
                              color: selected
                                  ? Theme.of(context)
                                      .colorScheme
                                      .primary
                                  : null,
                            ),
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 8),

                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          connectedNoteIds.isEmpty
                              ? 'Done'
                              : 'Done · ${connectedNoteIds.length} connected',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: selectedColor,

      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,

        leading: IconButton(
          tooltip: 'Close',
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.close_rounded,
            color: Colors.black87,
          ),
        ),

        title: const Text(
          'New Note',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w700,
          ),
        ),

        actions: [
          IconButton(
            tooltip: 'Capture Thought',
            onPressed: () {
              setState(() {
                isQuickThought =
                    !isQuickThought;
              });
            },
            icon: Icon(
              isQuickThought
                  ? Icons.bolt_rounded
                  : Icons.bolt_outlined,
              color: Colors.black87,
            ),
          ),

          IconButton(
            tooltip: 'Night Note',
            onPressed: () {
              setState(() {
                isNightNote = !isNightNote;
              });
            },
            icon: Icon(
              isNightNote
                  ? Icons.nightlight_rounded
                  : Icons.nightlight_outlined,
              color: Colors.black87,
            ),
          ),

          IconButton(
            tooltip:
                pinned ? 'Unpin' : 'Pin',
            onPressed: () {
              setState(() {
                pinned = !pinned;
              });
            },
            icon: Icon(
              pinned
                  ? Icons.push_pin_rounded
                  : Icons.push_pin_outlined,
              color: Colors.black87,
            ),
          ),

          IconButton(
            tooltip: 'Save',
            onPressed: save,
            icon: const Icon(
              Icons.check_rounded,
              color: Colors.black87,
              size: 28,
            ),
          ),

          const SizedBox(width: 8),
        ],
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            20,
            10,
            20,
            16,
          ),

          child: Column(
            children: [
              if (isQuickThought)
                _quickThoughtBanner(),

              TextField(
                controller: titleController,
                textCapitalization:
                    TextCapitalization.sentences,
                decoration:
                    const InputDecoration(
                  hintText: 'Title',
                  hintStyle: TextStyle(
                    color: Colors.black45,
                  ),
                  border:
                      InputBorder.none,
                  filled: false,
                ),
                style:
                    const TextStyle(
                  color: Colors.black87,
                  fontSize: 28,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),

              const SizedBox(height: 8),

              if (imagePath != null) ...[
                _imagePreview(),
                const SizedBox(height: 12),
              ],

              Expanded(
                child: TextField(
                  controller:
                      textController,
                  textCapitalization:
                      TextCapitalization
                          .sentences,
                  decoration:
                      const InputDecoration(
                    hintText:
                        'Write your thoughts...',
                    hintStyle:
                        TextStyle(
                      color:
                          Colors.black45,
                    ),
                    border:
                        InputBorder.none,
                    filled: false,
                  ),
                  maxLines: null,
                  expands: true,
                  textAlignVertical:
                      TextAlignVertical.top,
                  style:
                      const TextStyle(
                    color:
                        Colors.black87,
                    fontSize: 17,
                    height: 1.55,
                  ),
                ),
              ),

              _atmosphereSelector(),

              const SizedBox(height: 8),

              _moodSelector(),

              const SizedBox(height: 8),

              _featureButtons(),

              const SizedBox(height: 8),

              _bottomTools(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quickThoughtBanner() {
    return Container(
      width: double.infinity,
      margin:
          const EdgeInsets.only(bottom: 10),
      padding:
          const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color:
            Colors.white.withOpacity(0.70),
        borderRadius:
            BorderRadius.circular(18),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.bolt_rounded,
            size: 19,
            color: Colors.black87,
          ),
          SizedBox(width: 8),
          Text(
            'Quick Thought',
            style: TextStyle(
              fontWeight:
                  FontWeight.w700,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _featureButtons() {
    return SizedBox(
      height: 42,
      child: Row(
        children: [
          Expanded(
            child: _featureButton(
              icon: isNightNote
                  ? Icons.nightlight_rounded
                  : Icons.nightlight_outlined,
              title: 'Night Note',
              selected: isNightNote,
              onTap: () {
                setState(() {
                  isNightNote =
                      !isNightNote;
                });
              },
            ),
          ),

          const SizedBox(width: 8),

          Expanded(
            child: _featureButton(
              icon: Icons.link_rounded,
              title: connectedNoteIds.isEmpty
                  ? 'Connect'
                  : 'Connected ${connectedNoteIds.length}',
              selected:
                  connectedNoteIds.isNotEmpty,
              onTap: showConnections,
            ),
          ),
        ],
      ),
    );
  }

  Widget _featureButton({
    required IconData icon,
    required String title,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration:
            const Duration(milliseconds: 180),
        padding:
            const EdgeInsets.symmetric(
          horizontal: 12,
        ),
        decoration: BoxDecoration(
          color: selected
              ? Colors.black87
              : Colors.white.withOpacity(0.70),
          borderRadius:
              BorderRadius.circular(18),
        ),
        child: Row(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 17,
              color: selected
                  ? Colors.white
                  : Colors.black87,
            ),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                title,
                maxLines: 1,
                overflow:
                    TextOverflow.ellipsis,
                style: TextStyle(
                  color: selected
                      ? Colors.white
                      : Colors.black87,
                  fontSize: 11,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _atmosphereSelector() {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection:
            Axis.horizontal,
        itemCount:
            atmospheres.length,
        separatorBuilder:
            (_, __) {
          return const SizedBox(
            width: 8,
          );
        },
        itemBuilder:
            (context, index) {
          final atmosphere =
              atmospheres[index];

          final id =
              atmosphere['id'] as String;
          final name =
              atmosphere['name'] as String;
          final icon =
              atmosphere['icon'] as IconData;

          final selected =
              selectedAtmosphere == id;

          return GestureDetector(
            onTap: () {
              setState(() {
                selectedAtmosphere =
                    id;
              });
            },
            child:
                AnimatedContainer(
              duration:
                  const Duration(
                milliseconds: 180,
              ),
              padding:
                  const EdgeInsets
                      .symmetric(
                horizontal: 13,
              ),
              decoration:
                  BoxDecoration(
                color: selected
                    ? Colors.black87
                    : Colors.white
                        .withOpacity(
                        0.70,
                      ),
                borderRadius:
                    BorderRadius.circular(
                  18,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    icon,
                    size: 17,
                    color: selected
                        ? Colors.white
                        : Colors.black87,
                  ),
                  const SizedBox(
                    width: 6,
                  ),
                  Text(
                    name,
                    style:
                        TextStyle(
                      color: selected
                          ? Colors.white
                          : Colors.black87,
                      fontSize: 12,
                      fontWeight:
                          FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _moodSelector() {
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection:
            Axis.horizontal,
        itemCount:
            moods.length,
        separatorBuilder:
            (_, __) {
          return const SizedBox(
            width: 8,
          );
        },
        itemBuilder:
            (context, index) {
          final mood =
              moods[index];

          final id =
              mood['id'] as String;
          final name =
              mood['name'] as String;
          final icon =
              mood['icon'] as IconData;

          final selected =
              selectedMood == id;

          return GestureDetector(
            onTap: () {
              setState(() {
                selectedMood =
                    selected ? null : id;
              });
            },
            child:
                AnimatedContainer(
              duration:
                  const Duration(
                milliseconds: 180,
              ),
              padding:
                  const EdgeInsets
                      .symmetric(
                horizontal: 12,
              ),
              decoration:
                  BoxDecoration(
                color: selected
                    ? Colors.black87
                    : Colors.white
                        .withOpacity(
                        0.70,
                      ),
                borderRadius:
                    BorderRadius.circular(
                  17,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    icon,
                    size: 16,
                    color: selected
                        ? Colors.white
                        : Colors.black87,
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  Text(
                    name,
                    style:
                        TextStyle(
                      color: selected
                          ? Colors.white
                          : Colors.black87,
                      fontSize: 11,
                      fontWeight:
                          FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _bottomTools() {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color:
            Colors.white.withOpacity(
          0.75,
        ),
        borderRadius:
            BorderRadius.circular(
          22,
        ),
      ),
      child: Row(
        children: [
          _toolButton(
            icon:
                Icons.image_outlined,
            onTap: pickImage,
          ),

          const SizedBox(width: 10),

          Expanded(
            child: SizedBox(
              height: 42,
              child:
                  ListView.separated(
                scrollDirection:
                    Axis.horizontal,
                itemCount:
                    colors.length,
                separatorBuilder:
                    (_, __) {
                  return const SizedBox(
                    width: 9,
                  );
                },
                itemBuilder:
                    (context, index) {
                  return _colorButton(
                    colors[index],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _imagePreview() {
    return Stack(
      children: [
        ClipRRect(
          borderRadius:
              BorderRadius.circular(
            22,
          ),
          child: Image.file(
            File(imagePath!),
            width:
                double.infinity,
            height: 190,
            fit: BoxFit.cover,
          ),
        ),

        Positioned(
          top: 10,
          right: 10,
          child: Material(
            color:
                Colors.black.withOpacity(
              0.60,
            ),
            shape:
                const CircleBorder(),
            child: InkWell(
              customBorder:
                  const CircleBorder(),
              onTap:
                  removeImage,
              child:
                  const Padding(
                padding:
                    EdgeInsets.all(
                  8,
                ),
                child: Icon(
                  Icons.close_rounded,
                  color:
                      Colors.white,
                  size: 20,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _toolButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      shape:
          const CircleBorder(),
      child: InkWell(
        customBorder:
            const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding:
              const EdgeInsets.all(
            10,
          ),
          child: Icon(
            icon,
            color:
                Colors.black87,
            size: 22,
          ),
        ),
      ),
    );
  }

  Widget _colorButton(
    Color color,
  ) {
    final selected =
        color.value ==
            selectedColor.value;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedColor =
              color;
        });
      },
      child:
          AnimatedContainer(
        duration:
            const Duration(
          milliseconds: 180,
        ),
        width:
            selected ? 38 : 34,
        height:
            selected ? 38 : 34,
        decoration:
            BoxDecoration(
          color: color,
          shape:
              BoxShape.circle,
          border:
              Border.all(
            color: selected
                ? Colors.black87
                : Colors.white,
            width: selected
                ? 2.5
                : 1.5,
          ),
        ),
        child: selected
            ? const Icon(
                Icons.check_rounded,
                color:
                    Colors.black87,
                size: 18,
              )
            : null,
      ),
    );
  }
}